export default [{
  id: 'u1',
  name: 'Vadim',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/1.jpg',
  status: "Hello there, how are you"
}, {
  id: 'u2',
  name: 'Lukas',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/2.jpg',
}, {
  id: 'u3',
  name: 'Daniil',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/3.jpg',
}, {
  id: 'u4',
  name: 'Alex',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/3.png',
}, {
  id: 'u5',
  name: 'Vlad',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/4.jpg',
}, {
  id: 'u6',
  name: 'Elon Musk',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/5.jpg',
}, {
  id: 'u7',
  name: 'Adrian',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/6.png',
}, {
  id: 'u8',
  name: 'Borja',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/7.png',
}, {
  id: 'u9',
  name: 'Mom',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/8.png',
}, {
  id: 'u10',
  name: 'Angelina Jolie',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/9.png',
}]
